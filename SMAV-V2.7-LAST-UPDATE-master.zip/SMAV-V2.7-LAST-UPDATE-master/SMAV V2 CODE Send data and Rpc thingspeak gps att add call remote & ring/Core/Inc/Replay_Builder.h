/*
 * Reply_Builder.h
 *
 *  Created on: Aug 22, 2021
 *      Author: LUIS
 */

#ifndef INC_REPLAY_BUILDER_H_
#define INC_REPLAY_BUILDER_H_

char* getAlarmMsg(int alarmID);
char* getReplayMsg(int replyID);

#endif /* INC_REPLAY_BUILDER_H_ */
