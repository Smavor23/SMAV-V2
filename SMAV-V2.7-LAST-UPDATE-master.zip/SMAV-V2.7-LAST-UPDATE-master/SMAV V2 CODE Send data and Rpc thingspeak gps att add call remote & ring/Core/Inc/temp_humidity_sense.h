/*
 * temp_humidity_sense.h
 *
 *  Created on: 15 ene. 2022
 *      Author: LUIS
 */

#ifndef SRC_TEMP_HUMIDITY_SENSE_H_
#define SRC_TEMP_HUMIDITY_SENSE_H_

char* getTemperatureString();
char* getHumidityString();
char* getDewPointString();

#endif /* SRC_TEMP_HUMIDITY_SENSE_H_ */
